﻿using Maryam_project.Models;
using System;

namespace Maryam_project.Controllers
{
    internal class Model12
    {
        public object M_Admin { get; internal set; }

        internal void SaveChanges()
        {
            throw new NotImplementedException();
        }

        internal object Entry(M_Admin m_Admin)
        {
            throw new NotImplementedException();
        }
    }
}